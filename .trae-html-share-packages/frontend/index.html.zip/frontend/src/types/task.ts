/**
 * Agent 执行日志状态枚举
 */
export enum AgentLogStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed'
}

/**
 * Agent 执行日志状态标签映射
 */
export const AgentLogStatusLabels: Record<AgentLogStatus, string> = {
  [AgentLogStatus.PENDING]: '待执行',
  [AgentLogStatus.RUNNING]: '执行中',
  [AgentLogStatus.COMPLETED]: '已完成',
  [AgentLogStatus.FAILED]: '失败'
}

/**
 * Agent 执行日志
 */
export interface AgentLog {
  agent_name: string
  step: string
  start_time: string | null
  end_time: string | null
  status: AgentLogStatus | string
  message: string | null
  output_summary: string | null
  // Trace 可观测性字段
  input_data: Record<string, unknown> | null
  output_data: Record<string, unknown> | null
  prompt_template: string | null
  prompt_variables: Record<string, unknown> | null
  input_tokens: number
  output_tokens: number
  total_tokens: number
  cost_cny: number
  latency_ms: number | null
  model_name: string | null
  provider: string | null
  child_calls: ChildCallRecord[]
}

/**
 * 构造一条字段完整的空 AgentLog。
 *
 * 工作流步骤合成日志、列表缺省展示等场景必须走这里，
 * 避免只填部分字段导致 vue-tsc 类型失败。
 */
export function createEmptyAgentLog(
  partial: Pick<AgentLog, 'agent_name' | 'step'> &
    Partial<Omit<AgentLog, 'agent_name' | 'step'>>
): AgentLog {
  return {
    start_time: null,
    end_time: null,
    status: AgentLogStatus.PENDING,
    message: null,
    output_summary: null,
    input_data: null,
    output_data: null,
    prompt_template: null,
    prompt_variables: null,
    input_tokens: 0,
    output_tokens: 0,
    total_tokens: 0,
    cost_cny: 0,
    latency_ms: null,
    model_name: null,
    provider: null,
    child_calls: [],
    ...partial
  }
}

/**
 * 子调用记录（工具调用、嵌套 LLM 调用）
 */
export interface ChildCallRecord {
  call_type: 'tool' | 'llm' | 'rag'
  name: string
  input: string | null
  output: string | null
  latency_ms: number | null
  tokens?: number
}

/**
 * 任务类型枚举
 */
export enum TaskType {
  IMAGE_ONLY = 'image_only',
  VIDEO_ONLY = 'video_only',
  IMAGE_AND_VIDEO = 'image_and_video'
}

/**
 * 任务类型标签映射
 */
export const TaskTypeLabels: Record<TaskType, string> = {
  [TaskType.IMAGE_ONLY]: '图片生成',
  [TaskType.VIDEO_ONLY]: '视频生成',
  [TaskType.IMAGE_AND_VIDEO]: '图片+视频'
}

/**
 * 任务状态枚举
 */
export enum TaskStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

/** 任务终态集合：completed / failed / cancelled */
export const TERMINAL_TASK_STATUSES: ReadonlySet<TaskStatus> = new Set<TaskStatus>([
  TaskStatus.COMPLETED,
  TaskStatus.FAILED,
  TaskStatus.CANCELLED
])

/**
 * 是否处于终态（completed/failed/cancelled）；空值视为非终态。
 */
export function isTerminalTaskStatus(
  status: TaskStatus | string | null | undefined
): boolean {
  return !!status && TERMINAL_TASK_STATUSES.has(status as TaskStatus)
}

/**
 * 是否处于运行中（仅 running）；空值视为非运行。
 */
export function isRunningTaskStatus(
  status: TaskStatus | string | null | undefined
): boolean {
  return status === TaskStatus.RUNNING
}

/**
 * 任务状态标签映射
 */
export const TaskStatusLabels: Record<TaskStatus, string> = {
  [TaskStatus.PENDING]: '待处理',
  [TaskStatus.RUNNING]: '运行中',
  [TaskStatus.COMPLETED]: '已完成',
  [TaskStatus.FAILED]: '失败',
  [TaskStatus.CANCELLED]: '已取消'
}

/**
 * 任务信息（列表项）
 */
export interface Task {
  task_id: string
  product_id: string
  status: TaskStatus
  progress: number
  current_step: string
  error_message?: string | null
  created_at: string
  updated_at: string
  request?: TaskRequest
}

/**
 * 任务详情
 */
export interface TaskDetail {
  task_id: string
  product_id: string
  task_type: TaskType
  status: TaskStatus
  progress: number
  current_step: string
  completed_steps: string[]
  agent_logs: AgentLog[]
  images: ImageResult[]
  video: VideoResult | null
  quality_reports: QualityReport[]
  error_message: string | null
  has_mock_assets?: boolean
  created_at: string
  updated_at: string
  state?: Record<string, unknown>
}

/**
 * 图片结果
 */
export interface ImageResult {
  image_id: string
  image_type: string
  url: string
  status: string
}

/**
 * 视频结果
 */
export interface VideoResult {
  video_id: string
  url: string
  duration: number
  status: string
}

/**
 * 质量报告
 */
export interface QualityReport {
  report_id: string
  overall_score: number
  issues: string[]
  recommendations: string[]
}

/**
 * 任务请求配置
 */
export interface TaskRequest {
  task_id: string
  task_type: TaskType
  image_types: string[]
  image_count_per_type: number
  video_duration: number
  video_style: string
  style_preference: string | null
  color_preference: string | null
  quality_level: string
}

/**
 * 任务创建请求
 */
export interface TaskCreateRequest {
  product_id: string
  task_type: TaskType
  image_types?: string[]
  image_count_per_type?: number
  video_duration?: number
  video_style?: string
  style_preference?: string
  color_preference?: string
  quality_level?: string
  llm_provider_id?: number | null
  image_provider_id?: number | null
  video_provider_id?: number | null
}

/**
 * 任务状态响应
 */
export interface TaskStatusResponse {
  task_id: string
  status: TaskStatus
  progress: number
  current_step: string
  created_at: string
  updated_at: string
}

/**
 * 任务查询参数
 */
export interface TaskQueryParams {
  product_id?: string
  task_type?: TaskType
  status?: TaskStatus
  page?: number
  page_size?: number
}

// ==================== WebSocket 事件类型 ====================

/** Agent 状态变化事件 */
export interface AgentStatusChangeEvent {
  type: 'agent_status_change'
  agent_name: string
  status: AgentLogStatus | string
  progress?: number
}

/** Agent 日志更新事件 */
export interface AgentLogUpdateEvent {
  type: 'agent_log_update'
  agent_log: AgentLog
}

/** 全局进度更新事件 */
export interface ProgressUpdateEvent {
  type: 'progress_update'
  progress: number
  current_step: string
  /** 可选：轻量帧携带的任务状态（legacy 兼容） */
  status?: TaskStatus | string
}

/** WebSocket 事件联合类型 */
export type TaskWsEvent = AgentStatusChangeEvent | AgentLogUpdateEvent | ProgressUpdateEvent